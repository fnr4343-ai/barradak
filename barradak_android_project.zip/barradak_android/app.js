import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, addDoc, onSnapshot, query, orderBy, serverTimestamp, doc, updateDoc, increment } from 'firebase/firestore';

// ضع إعدادات تطبيق Firebase Web هنا. هذه الإعدادات ليست مفتاحًا إداريًا؛ لا تضع Service Account هنا.
const firebaseConfig = {
  apiKey: "PASTE_FIREBASE_WEB_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID",
  appId: "PASTE_FIREBASE_APP_ID"
};

const $ = (id) => document.getElementById(id);
const statusBanner = $('statusBanner');
const coolerList = $('coolerList');
const countLabel = $('countLabel');
const addDialog = $('addDialog');
const addForm = $('addForm');
let map, markersLayer, allCoolers = [], userLocation = null, selectedLatLng = null, authUser = null;
let db = null, firebaseReady = false, activeFilter = 'all';

const mosul = [36.335, 43.118];
const validConfig = !Object.values(firebaseConfig).some(v => String(v).startsWith('PASTE_'));

map = L.map('map', { zoomControl: false }).setView(mosul, 13);
L.control.zoom({ position: 'topright' }).addTo(map);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);
markersLayer = L.layerGroup().addTo(map);

const coolerIcon = (status) => L.divIcon({
  className: 'cooler-pin',
  html: `<div style="width:35px;height:35px;border:3px solid white;border-radius:13px 13px 13px 4px;transform:rotate(-45deg);background:${status==='available'?'#0e9d76':status==='empty'?'#e17b4b':'#e4a23b'};box-shadow:0 3px 10px #17333a40;display:grid;place-items:center"><span style="transform:rotate(45deg);font-size:17px">💧</span></div>`,
  iconSize: [35,35], iconAnchor: [17,30], popupAnchor: [0,-28]
});

function esc(s='') { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function distanceKm(a,b) {
  const rad = x => x * Math.PI / 180;
  const dLat=rad(b.lat-a.lat), dLng=rad(b.lng-a.lng);
  const h=Math.sin(dLat/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLng/2)**2;
  return 6371*2*Math.atan2(Math.sqrt(h),Math.sqrt(1-h));
}
function distanceText(c) {
  if (!userLocation) return 'المسافة تظهر بعد تحديد موقعك';
  const km=distanceKm(userLocation,{lat:c.lat,lng:c.lng});
  return km<1 ? `${Math.round(km*1000)} متر تقريبًا` : `${km.toFixed(1)} كم تقريبًا`;
}
function statusText(s) { return s==='available'?'الماء متوفر':s==='empty'?'فارغ حاليًا':'يحتاج تأكيد'; }
function statusClass(s) { return s==='available'?'good':s==='empty'?'bad':''; }
function render() {
  markersLayer.clearLayers();
  const search = $('searchInput').value.trim().toLowerCase();
  let list = allCoolers.filter(c => {
    const matchesSearch = !search || `${c.name||''} ${c.note||''}`.toLowerCase().includes(search);
    const matchesFilter = activeFilter==='all' || (activeFilter==='available' ? c.status==='available' : c.type==='public');
    return matchesSearch && matchesFilter;
  });
  if (userLocation) list.sort((a,b)=>distanceKm(userLocation,{lat:a.lat,lng:a.lng})-distanceKm(userLocation,{lat:b.lat,lng:b.lng}));
  else list.sort((a,b)=>(b.createdAtMs||0)-(a.createdAtMs||0));
  countLabel.textContent = `${list.length} برّاد`;
  for (const c of list) {
    const marker=L.marker([c.lat,c.lng],{icon:coolerIcon(c.status)}).addTo(markersLayer);
    marker.bindPopup(`<b>${esc(c.name)}</b><br>${esc(statusText(c.status))}<br>${esc(c.type==='public'?'عام للجميع':'خاص بإذن صاحبه')}<br>${esc(distanceText(c))}`);
    c._marker = marker;
  }
  if (!list.length) {
    coolerList.innerHTML = `<div class="empty-state"><b>ماكو برّادات مطابقة بعد</b>${firebaseReady?'كن أول شخص يضيف برّادًا موثوقًا قريبًا منك.':'أكمل إعداد Firebase حتى تظهر المواقع المشتركة.'}</div>`;
    return;
  }
  coolerList.innerHTML = list.slice(0,30).map(c => `
    <article class="cooler-card">
      <div class="cooler-icon">💧</div>
      <div class="cooler-info"><h3>${esc(c.name||'برّاد ماء')}</h3>
        <p>${esc(c.note|| (c.type==='public'?'برّاد عام':'برّاد خاص بإذن صاحبه'))}</p>
        <div class="meta-row"><span class="tag ${statusClass(c.status)}">${esc(statusText(c.status))}</span><span class="tag">${esc(c.type==='public'?'عام':'خاص بإذن')}</span><span class="tag">${esc(distanceText(c))}</span></div>
      </div>
      <div class="card-actions"><button class="mini-btn route" data-action="route" data-id="${esc(c.id)}">الاتجاهات</button><button class="mini-btn" data-action="focus" data-id="${esc(c.id)}">على الخريطة</button><button class="mini-btn" data-action="report" data-id="${esc(c.id)}">تحديث الحالة</button></div>
    </article>`).join('');
}
function setBanner(text, error=false) { statusBanner.textContent=text; statusBanner.style.color=error?'#a33b2e':'#637c7f'; }
function setCoordinates(lat,lng) {
  selectedLatLng={lat,lng}; $('latitude').value=lat; $('longitude').value=lng;
  $('coordsLabel').textContent=`${lat.toFixed(5)}, ${lng.toFixed(5)}`;
}
function locateMe() {
  if (!navigator.geolocation) { setBanner('هذا الجهاز لا يدعم تحديد الموقع.',true); return; }
  setBanner('جارٍ تحديد موقعك…');
  navigator.geolocation.getCurrentPosition(pos => {
    userLocation={lat:pos.coords.latitude,lng:pos.coords.longitude};
    map.setView([userLocation.lat,userLocation.lng],16);
    L.circleMarker([userLocation.lat,userLocation.lng],{radius:7,color:'#fff',weight:3,fillColor:'#087f8c',fillOpacity:1}).addTo(markersLayer).bindPopup('موقعك الحالي (لا يُحفظ في قاعدة البيانات)');
    if (addDialog.open) setCoordinates(userLocation.lat,userLocation.lng);
    render(); setBanner('تم تحديد موقعك. تُستخدم الإحداثيات على جهازك لفرز أقرب البرّادات.');
  }, err => {
    const msg=err.code===1?'لم تسمح بإذن الموقع. يمكنك استخدام الخريطة يدويًا.':'تعذر تحديد الموقع الآن. حاول مرة أخرى أو اختر الموقع من الخريطة.';
    setBanner(msg,true);
  }, {enableHighAccuracy:true,timeout:12000,maximumAge:30000});
}
function openAdd() {
  $('formError').textContent='';
  selectedLatLng=null; $('latitude').value=''; $('longitude').value='';
  $('coordsLabel').textContent='اضغط على الخريطة لاختيار موقع البرّاد';
  addDialog.showModal();
}
function startFirebase() {
  if (!validConfig) {
    setBanner('وضع المعاينة: أضف إعدادات Firebase في app.js لتفعيل قاعدة البيانات المشتركة.');
    allCoolers = demoCoolers(); render(); return;
  }
  try {
    const app=initializeApp(firebaseConfig);
    const auth=getAuth(app); db=getFirestore(app);
    onAuthStateChanged(auth, user => {
      authUser=user;
      if (!user) return;
      firebaseReady=true;
      setBanner('متصل بقاعدة البيانات المشتركة. المواقع المضافة تظهر للمستخدمين الآخرين.');
      const q=query(collection(db,'coolers'),orderBy('createdAt','desc'));
      onSnapshot(q, snap => {
        allCoolers=snap.docs.map(d=>({id:d.id,...d.data(),createdAtMs:d.data().createdAt?.toMillis?.()||0}))
          .filter(c=>Number.isFinite(c.lat)&&Number.isFinite(c.lng));
        render();
      }, err => {
        console.error(err); setBanner('تعذر تحميل المواقع. راجع قواعد Firestore وإعدادات Firebase.',true);
      });
    });
    signInAnonymously(auth).catch(err=>{console.error(err);setBanner('تعذر تسجيل الدخول المجهول. فعّله من Firebase Authentication.',true);});
  } catch (e) {
    console.error(e); setBanner('إعداد Firebase غير صحيح. راجع firebaseConfig في app.js.',true);
  }
}
function demoCoolers() {
  return [
    {id:'demo1',name:'مثال: برّاد عام',note:'هذا مثال توضيحي — ليس موقعًا مؤكدًا',type:'public',status:'unknown',lat:mosul[0]+0.008,lng:mosul[1]+0.006},
    {id:'demo2',name:'مثال: برّاد قرب جامع',note:'احذف الأمثلة بعد ربط قاعدة البيانات',type:'public',status:'available',lat:mosul[0]-0.006,lng:mosul[1]-0.008}
  ];
}
$('locateBtn').addEventListener('click',locateMe);
$('myLocationFab').addEventListener('click',locateMe);
$('useMyLoc').addEventListener('click',()=>{
  if(userLocation) setCoordinates(userLocation.lat,userLocation.lng);
  else navigator.geolocation ? navigator.geolocation.getCurrentPosition(p=>setCoordinates(p.coords.latitude,p.coords.longitude),()=>{$('formError').textContent='تعذر تحديد موقعك. اضغط على الخريطة لاختيار الموقع.';}) : $('formError').textContent='اختر الموقع من الخريطة.';
});
map.on('click',e=>{ if(addDialog.open) setCoordinates(e.latlng.lat,e.latlng.lng); });
$('addBtn').addEventListener('click',openAdd);
$('navAdd').addEventListener('click',openAdd);
$('closeDialog').addEventListener('click',()=>addDialog.close());
$('aboutBtn').addEventListener('click',()=>$('aboutDialog').showModal());
$('searchInput').addEventListener('input',render);
$('filterBtn').addEventListener('click',()=>{
  activeFilter=activeFilter==='all'?'available':activeFilter==='available'?'public':'all';
  $('filterBtn').textContent=activeFilter==='all'?'الكل ▾':activeFilter==='available'?'الماء متوفر ▾':'البرّادات العامة ▾';
  $('filterBtn').setAttribute('aria-pressed',String(activeFilter!=='all'));render();
});
coolerList.addEventListener('click',async e=>{
  const btn=e.target.closest('button[data-action]'); if(!btn)return;
  const c=allCoolers.find(x=>x.id===btn.dataset.id);if(!c)return;
  if(btn.dataset.action==='focus'){map.setView([c.lat,c.lng],17);if(c._marker)c._marker.openPopup();}
  if(btn.dataset.action==='route'){
    const origin=userLocation?`${userLocation.lat},${userLocation.lng}`:'';
    const dest=`${c.lat},${c.lng}`;
    window.open(`https://www.google.com/maps/dir/?api=1&${origin?'origin='+encodeURIComponent(origin)+'&':''}destination=${encodeURIComponent(dest)}&travelmode=walking`,'_blank','noopener');
  }
  if(btn.dataset.action==='report'){
    const choice=prompt('حدّث حالة الماء بكتابة رقم:\\n1 = الماء متوفر\\n2 = فارغ حاليًا\\n3 = غير متأكد');
    const mapStatus={'1':'available','2':'empty','3':'unknown'};
    if(!mapStatus[choice])return;
    if(!firebaseReady || !db || c.id.startsWith('demo')){setBanner('اربط Firebase أولًا حتى تُحفظ تحديثات الحالة بشكل مشترك.',true);return;}
    try{await updateDoc(doc(db,'coolers',c.id),{status:mapStatus[choice],updatedAt:serverTimestamp(),reports:increment(1)});setBanner('شكرًا! تم تحديث حالة البرّاد.');}
    catch(err){console.error(err);setBanner('تعذر حفظ التحديث. حاول لاحقًا.',true);}
  }
});
addForm.addEventListener('submit',async e=>{
  e.preventDefault(); $('formError').textContent='';
  const name=$('coolerName').value.trim(), lat=Number($('latitude').value),lng=Number($('longitude').value);
  if(name.length<3){$('formError').textContent='اكتب وصفًا واضحًا للمكان (3 أحرف على الأقل).';return;}
  if(!Number.isFinite(lat)||!Number.isFinite(lng)||!$('latitude').value||!$('longitude').value){$('formError').textContent='حدد موقع البرّاد بالضغط على الخريطة أو زر موقعي.';return;}
  if(!firebaseReady||!db||!authUser){$('formError').textContent='قاعدة البيانات المشتركة غير جاهزة. أكمل إعداد Firebase في README_AR.md.';return;}
  const submit=$('submitCooler');submit.disabled=true;submit.textContent='جارٍ النشر…';
  try{
    await addDoc(collection(db,'coolers'),{
      name, type:$('coolerType').value, status:$('waterStatus').value,
      note:$('coolerNote').value.trim(),lat,lng,
      createdAt:serverTimestamp(),updatedAt:serverTimestamp(),createdBy:authUser.uid,reports:0
    });
    addDialog.close();addForm.reset();setBanner('تم نشر البرّاد على الخريطة المشتركة. شكرًا لمساهمتك! 💧');
    map.setView([lat,lng],16);
  }catch(err){console.error(err);$('formError').textContent='لم يتم النشر. تحقق من الإنترنت وقواعد Firestore ثم حاول مجددًا.';}
  finally{submit.disabled=false;submit.textContent='نشر البرّاد على الخريطة';}
});
startFirebase();
